from django.shortcuts import render

import blog
from .models import Blog

# Create your views here.
def all_blogs(request):
    blogs = blog.objects.order_by('-date')
    return render(request ,'blog/all_blog.html',{'blog':blogs})