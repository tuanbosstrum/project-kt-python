tinh = ("Huế","Quảng Bình","Quảng Trị")
mien_nam = ("TP.HCM","Đồng Nai","Bình Dương")

print(tinh)
print(mien_nam)

ds_vung_do = tinh + mien_nam
print(ds_vung_do)

print(ds_vung_do[0])