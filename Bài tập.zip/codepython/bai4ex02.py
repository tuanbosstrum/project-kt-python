danhsach = []
hoten = input("Nhập họ tên:")
danhsach.append(hoten)

hoten = input("Nhập họ tên:")
danhsach.append(hoten)

hoten = input("Nhập họ tên:")
danhsach.append(hoten)

hoten = input("Nhập họ tên:")
danhsach.append(hoten)

hoten = input("Nhập họ tên:")
danhsach.append(hoten)
print(danhsach)

vitri = int(input("Bạn muốn chỉnh vị trị thứ mấy:"))
hoten = input("Nhập họ tên mới:")
danhsach[vitri] = hoten
print(danhsach)
print(danhsach.sort())