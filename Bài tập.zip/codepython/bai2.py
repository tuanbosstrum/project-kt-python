import math
    
n = 99999999999999999999999999999
diem = 9.5
print(math.floor(diem))
print(math.ceil(diem))

ho_ten, tuoi, dia_chi = "Hoàng Tuấn", 18, "149, Phan Bội Châu, tp.Huế"
print(ho_ten, tuoi, dia_chi)
SO_LUONG_SV = 100
print(type(diem))
print(type(dia_chi))
print(type(n))
