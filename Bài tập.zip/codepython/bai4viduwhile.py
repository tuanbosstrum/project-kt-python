def main():
    x=0
    #define a while loop
    while(x <4):
        print(x)
        x = x+1

if __name__ == "__main__":
   main()