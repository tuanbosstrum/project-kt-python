#hàm set
dstinh = {"Huế", "Đà Nẵng", "Quảng Nam"}

dstinh.add("Quảng Ngãi")
dstinh.remove("Đà Nẵng")

for tinh in dstinh:
    print(tinh)