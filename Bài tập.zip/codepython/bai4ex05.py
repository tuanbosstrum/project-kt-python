#hàm thường
hoten = "Hoàng Tuấn"
print(hoten)
namsinh = 1990
tuoi = 2021 - namsinh
print(f"tuoi = {tuoi}")