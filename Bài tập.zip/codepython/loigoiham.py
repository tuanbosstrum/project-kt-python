# def hello():
#     print("Ciao Tuấn")
# hello()

# def pt(x):
#     print(x*2)
# pt(2)

def tong():
    a = 20
    b = 200
    s = a + b
    print("tổng:" + str(s))
tong()