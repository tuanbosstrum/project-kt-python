from django.shortcuts import render
from django.http import HttpResponse,response
import random
def home(request):
  return render(request,'generator/home.html')

def password(request):
    thepassword=''
    characters = list('agasgaklsgaglwltpwapktwpw')
    if request.GET.get('uppercase'):
        characters.extend(list('ABCDEFATWPLXAOZGI'))
    if request.GET.get('special'):
        characters.extend(list('!@#$%&*()_!'))
    if request.GET.get('number'):
        characters.extend(list('123456789123156456456'))
    length = int(request.GET.get('length'))
    for x in range(length):
        thepassword += random.choice(characters)
    return render(request,'generator/password.html',{'password':thepassword})